pg=16384
ceph_node="CephXCD"
poolname="xcd_8osd"
vol_size=25600

echo "mkfs.ceph"
ssh ${ceph_node} "service ceph -a stop"
ssh ${ceph_node} "rm -r /data/mon.CephXCD"
ssh ${ceph_node} "mkcephfs -a -c /etc/ceph/ceph.conf --mkfs"
ssh ${ceph_node} "service ceph -a start"

sleep 10

echo "create pool"
ssh ${ceph_node} "ceph osd pool delete data data --yes-i-really-really-mean-it"
ssh ${ceph_node} "ceph osd pool delete metadata metadata --yes-i-really-really-mean-it"
ssh ${ceph_node} "ceph osd pool delete rbd rbd --yes-i-really-really-mean-it"
ssh ${ceph_node} "ceph osd pool create "${poolname}" "${pg}" "${pg}

echo "create volume"
for vol_id in `seq 1 8`
do
	ssh ${ceph_node} "rbd -p "${poolname}" create --size "${vol_size}" --image-format 2 volume-"${vol_id}
done

ssh ${ceph_node} "rbd -p "${poolname}" ls"

echo "reboot all VMs and attach volumes"
./vm_reboot.sh "13 5 3 6" "1 2"
echo "finished reboot vm, start to sleep 30s"
sleep 30
echo "dd all volumes"
for i in `seq 11 18`
do
	ssh 192.168.100.${i} "dd if=/dev/zero of=/dev/vdb bs=1M &" &
done



