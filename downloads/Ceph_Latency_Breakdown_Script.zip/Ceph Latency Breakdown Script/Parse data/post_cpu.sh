if [ $# != 6 ] ; then
    echo " "
    echo "Description:"
    echo "    This script attempts ."
    echo " "
    echo "usage:"
    echo "    $0 total_vm op req_size operate_key (4/6/7/12) prefix ip_file"
    echo " "
    exit
fi

#set -x
total_vm=$1
op=$2
req_size=$3
operate_key=$4
prefix=$5
ip_file=$6

ceph_host="CephXCD"
#changed by XCD
w_arrary=(0 0 0 0 0 0 0 0 0)

j=1

#file="/mnt/${prefix}/${op}/`expr ${total_vm} - 1`instance/${req_size}/ceph-${ceph_host}_sar.txt"
file="/data/xcd/${prefix}/${op}/`expr ${total_vm} - 1`instance/${req_size}/ceph-${ceph_host}_mpstat.txt"
#	echo "$file"
if [ ! -f "$file" ];then
	exit
fi
#echo `grep "CPU" -A 1 ${file} | grep "all" | head -800 | awk -v col=$operate_key 'BEGIN{count=0}{if($col<=100&&$col>0){total+=$col;count++;}}END{print total/count}'`
#echo `grep "all"  ${file} | head -500 | tail -400 | awk -v col=$operate_key '{total+=$col;}END{print total/NR}'`
echo `grep "all"  ${file} | tac | awk -v col=$operate_key 'BEGIN{count=0;flag=0}{if($dex!=0||flag==1){flag=1;total+=$col;count++}}END{print total/count}'`
#echo `cat  ${file} | awk -v cpuid=3 -v col=$operate_key '{if($cpuid==1){printf($col);total+=$col;}}END{print total/NR}'`
#echo `grep "CPU" -A 2 ${file} | grep -A 1 "all" |grep -v "all\|--" | head -400 | awk -v col=$operate_key 'BEGIN{count=0}{if($col<=100&&$col>0){total+=$col;count++;}}END{print total/count}'`
