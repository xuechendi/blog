for j in `seq 164 165`
do
	for i in 1 2 3 4 5 6 7 8
	do
		mkdir -p Lat_breakdown_res/run${j}/${i}vm
		path="/data/xcd/ceph-CephXCD/run${j}/vmNum_${i}/3/`expr ${i} - 1`instance/4k/"
		for m in `ls ${path} | grep asok | grep node`
		do
			echo "===========${path}${m}============"
			python post_perf.py ${path}${m} client > Lat_breakdown_res/run${j}/${i}vm/${m}
		done
		for m in `ls ${path} | grep asok | grep osd`
		do
			echo "===========${path}${m}============"
			python post_perf.py ${path}${m} server > Lat_breakdown_res/run${j}/${i}vm/${m}
		done
	done
done
