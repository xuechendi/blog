for j in `seq 164 165`
do
	echo "==========run${j}==========="
	for i in 1 2 3 4 5 6 7 8
	do
#		echo "=======${i}========="
		./post_volume_xcd.sh ${i} 3 4k read_iops ceph-CephXCD/run${j}/vmNum_${i} node13_net
	#	./post_volume_xcd.sh ${i} 0 64k write_bw ceph-CephXCD/run${j}/vmNum_${i} node13_net
	#	./post_volume_xcd.sh ${i} 1 64k read_bw ceph-CephXCD/run${j}/vmNum_${i} node13_net
	done
	#for i in 1 2 3 4 5 6 7 8
	#do
	#	./post_osd.sh ${i} 0 write_bw 64k ceph-CephXCD/run${j}/vmNum_${i}
	#	./post_osd.sh ${i} 1 read_bw 64k ceph-CephXCD/run${j}/vmNum_${i}
	#done
	for i in 1 2 3 4 5 6 7 8
	do
		./post_volume_xcd.sh ${i} 3 4k read_latency ceph-CephXCD/run${j}/vmNum_${i} node13_net
	#	./post_volume_xcd.sh ${i} 0 64k write_bw ceph-CephXCD/run${j}/vmNum_${i} node13_net
	#	./post_volume_xcd.sh ${i} 1 64k read_bw ceph-CephXCD/run${j}/vmNum_${i} node13_net
	done
	for k in 4 6 7 12;
	do		
		echo ${k}
		for i in 1 2 3 4 5 6 7 8
		do
			./post_cpu.sh ${i} 3 4k ${k} ceph-CephXCD/run${j}/vmNum_${i} node13_net
	#		./post_cpu.sh ${i} 0 64k ${k} ceph-CephXCD/run${j}/vmNum_${i} node13_net
	#		./post_cpu.sh ${i} 1 64k ${k} ceph-CephXCD/run${j}/vmNum_${i} node13_net
		done
	done
done
