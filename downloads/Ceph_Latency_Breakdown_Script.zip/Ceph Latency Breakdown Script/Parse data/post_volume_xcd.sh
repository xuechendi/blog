if [ $# != 6 ] ; then
    echo " "
    echo "Description:"
    echo "    This script attempts ."
    echo " "
    echo "usage:"
    echo "    $0 total_vm op req_size operate_key (write_iops/write_bw/write_latency/read_iops/read_bw/read_latency/latency) prefix ip_file"
    echo " "
    exit
fi

#set -x
total_vm=$1
op=$2
req_size=$3
operate_key=$4
prefix=$5
ip_file=$6

#changed by XCD
w_arrary=(0 0 0 0 0 0 0 0 0)

j=1
cat ${ip_file} | awk '{print $1}'|while read vm_node
do
	host=`cat ${ip_file} | grep ${vm_node} | awk '{print $3}'`
	file="/data/xcd/${prefix}/${op}/`expr ${total_vm} - 1`instance/${req_size}/${host}_${vm_node}_iostat.txt"
#	echo "$file"
    if [ ! -f "$file" ];then
		continue
	fi
	disk="vdb"
	index=`expr $j - 1`
	j=`expr $j + 1`
#	echo "./iostat.sh ${file} ${disk} $operate_key"
	w_arrary[${index}]=`./iostat.sh ${file} ${disk} $operate_key`
	if [ "${w_arrary[${index}]}" = "999999" ];then
		w_arrary[${index}]=0
	fi
printf "%.2f " ${w_arrary[${index}]}
done
printf "\n"
#echo "${w_arrary[0]};${w_arrary[1]};${w_arrary[2]};${w_arrary[3]};${w_arrary[4]};${w_arrary[5]};${w_arrary[6]};${w_arrary[7]};${w_arrary[8]}"
#done
