#run_list="117 118 119 120 121 122 123 124 125"
run_list=$1
vm_list="1 2 3 4 5 6 7 8"
#vm_list="1"

for i in ${run_list}
do
	for j in ${vm_list}
	do
		echo "=========run${i}/${j}=========="
		
		printf "avg_qlen\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep node`
		do
			res=`cat ${path}${cfile} | awk -v col=4 'BEGIN{count=0}{if($col>0){total+=$col;count++}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				printf "%.3f\t" ${res}
			fi
		done

		printf "\naio_rd_submit_latency\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep node`
		do
			res=`cat ${path}${cfile} | awk -v col=6 'BEGIN{count=0}{if($col>0&&$col<1){total+=$col;count++}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				res=$(awk -v input=${res} 'BEGIN{printf "%.3f", input*1000 }')
				printf "%.3f\t" ${res}
			fi
		done

		printf "\naio_rd_latency\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep node`
		do
			res=`cat ${path}${cfile} | awk -v col=8 'BEGIN{count=0}{if($col>0&&$col<1){total+=$col;count++;$col;}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				res=$(awk -v input=${res} 'BEGIN{printf "%.3f", input*1000 }')
				printf "%.3f\t" ${res}
			fi
		done

		printf "\navg_osd_queue_length\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep osd`
		do
			res=`cat ${path}${cfile} | awk -v col=18 'BEGIN{count=0}{if($col>0){total+=$col;count++}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0"  ];then
				printf "%.3f\t" ${res}
			fi
		done

		printf "\nop_network_read_latency\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep osd`
		do
			res=`cat ${path}${cfile} | awk -v col=6 'BEGIN{count=0}{if($col>0&&$col<1){total+=$col;count++}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				res=$(awk -v input=${res} 'BEGIN{printf "%.3f", input*1000 }')
				printf "%.3f\t" ${res}
			fi
		done

		printf "\nop_dispatch_latency\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep osd`
		do
			res=`cat ${path}${cfile} | awk -v col=8 'BEGIN{count=0}{if($col>0&&$col<1){total+=$col;count++}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				res=$(awk -v input=${res} 'BEGIN{printf "%.3f", input*1000 }')
				printf "%.3f\t" ${res}
			fi
		done

		printf "\nop_enqueue_latency\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep osd`
		do
			res=`cat ${path}${cfile} | awk -v col=10 'BEGIN{count=0}{if($col>0&&$col<1){total+=$col;count++}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				res=$(awk -v input=${res} 'BEGIN{printf "%.3f", input*1000 }')
				printf "%.3f\t" ${res}
			fi
		done

		printf "\nop_dequeue_latency\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep osd`
		do
			res=`cat ${path}${cfile} | awk -v col=12 'BEGIN{count=0}{if($col>0&&$col<1){total+=$col;count++}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				res=$(awk -v input=${res} 'BEGIN{printf "%.3f", input*1000 }')
				printf "%.3f\t" ${res}
			fi
		done

		printf "\nop_r_latency\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep osd`
		do
			res=`cat ${path}${cfile} | awk -v col=14 'BEGIN{count=0}{if($col>0&&$col<1){total+=$col;count++}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				res=$(awk -v input=${res} 'BEGIN{printf "%.3f", input*1000 }')
				printf "%.3f\t" ${res}
			fi
		done

		printf "\nop_get_pg_lock_latency\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep osd`
		do
			res=`cat ${path}${cfile} | awk -v col=16 'BEGIN{count=0}{if($col>0&&$col<1){total+=$col;count++}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				res=$(awk -v input=${res} 'BEGIN{printf "%.3f", input*1000 }')
				printf "%.3f\t" ${res}
			fi
		done

		printf "\nfilestore_read_avg_latency\t" 
		path="Lat_breakdown_res/run${i}/${j}vm/"
		for cfile in `ls ${path} | grep osd`
		do
			res=`cat ${path}${cfile} | awk -v col=4 'BEGIN{count=0}{if($col>0&&$col<1){total+=$col;count++;}}END{if(count>0){print total/count}}'`
			if [ "${res}" != "" ] && [ "${res}" != "0" ];then
				res=$(awk -v input=${res} 'BEGIN{printf "%.3f", input*1000 }')
				printf "%.3f\t" ${res}
			fi
		done
		printf "\n\n"
	done
done
