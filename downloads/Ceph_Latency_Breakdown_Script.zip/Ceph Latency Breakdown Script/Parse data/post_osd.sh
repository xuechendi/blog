if [ $# != 5 -a $# != 6 ] ; then
    echo " "
    echo "Description:"
    echo "    This script attempts ."
    echo " "
    echo "usage:"
    echo "    $0 total_disk op operate_key (write_iops/write_bw/write_latency/read_iops/read_bw/read_latency/latency) record_size prefix"
    echo " "
fi

total_disk=$1
op=$2
operate_key=$3
record_size=$4
prefix=$5
host="ceph-CephXCD"

file="/data/xcd/${host}/ceph.conf"

cat $file | grep "osd\."  | sed 's/\[//g' | sed 's/\]//g'  > osd.list
if [ "$6" = "--show_title" ]; then 
	cat osd.list | while read osd
	do
		printf "${osd}\t"
	done
	printf "\n"
fi
sum="0"
cat osd.list | while read line
do
    dev=`cat $file | grep -w -A 6 $line | grep -w devs | awk -F/ '{print $3}'`
	dev=${dev%?}
    data_file="/data/xcd/${prefix}/${op}/`expr ${total_disk} - 1`instance/${record_size}/${host}_iostat.txt"
#    echo $data_file"  "$dev 
#    echo "./iostat.sh ${data_file} ${dev} $operate_key"
    performace=`./iostat.sh ${data_file} ${dev} $operate_key`
#    sum=$(( ${sum} + ${performace} ))
#    sum=`echo $sum + $performace | bc`
#    echo "$host $dev $performace $sum"
    printf "${performace}\t"
done
printf "\n"
rm -f osd.list
