if [ $# != 3 ] ; then
    echo " "
    echo "Description:"
    echo "    This script attempts ."
    echo " "
    echo "usage:"
    echo "    $0 file disk operate_key (write_iops/write_bw/write_latency/read_iops/read_bw/read_latency/latency)"
    echo " "
    exit
fi

file=$1
disk=$2
operate_key=$3

case $operate_key in
"write_iops")
    index=5
    ;;
"write_bw")
    index=7
    ;;
"write_latency")
    index=12
    ;;
"read_iops")
    index=4
    ;;
"read_bw")
    index=6
    ;;
"read_latency")
    index=11
    ;;
"latency")
    index=10
    ;;
"avgrq-sz")
    index=8
    ;;
"avgqu-sz")
    index=9
    ;;
"util")
    index=14
    ;;
*)
    echo " operate_key error !"
    exit
    ;;
esac

if [ -e $file ]
then
#    performance=`cat $file | grep -w ${disk} | sed 1d |  tail -600 |awk -v dex=$index '{total+=$dex}END{print total/NR}'`
#  performance=`cat $file | grep -w ${disk} | sed 1d |head -500| tail -400 |awk -v dex=$index '{total+=$dex}END{print total/NR}'`
#   performance=`cat $file | grep -w ${disk} | sed 1d |head -300| tail -250 |awk -v dex=$index '{total+=$dex}END{print total/NR}'`
   performance=`grep -w ${disk} $file | sed 1d | tac |awk -v dex=$index 'BEGIN{count=0;flag=0}{if($dex!=0||flag==1){flag=1;total+=$dex;count++}}END{print total/count}'`
#   performance=`cat $file | grep -w ${disk} | sed 1d | awk -v dex=$index '{print $dex}'`
    echo "$performance"
else
    echo "999999"
fi

