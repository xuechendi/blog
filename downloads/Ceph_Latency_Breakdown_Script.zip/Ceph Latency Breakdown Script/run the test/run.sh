#result_path="/mnt/ceph-CephXCD/"
result_path="/data/xcd/ceph-CephXCD/"
ceph_node="CephXCD"
id=164

#op thread=20 16 8 4 32
#for i in 32 16 8 4
#for i in 1 2 4 8 16 32 64 128 256
for i in 256 16
#for i in 16
do
#	ssh ${ceph_node} "cp /etc/ceph/ceph.conf."${i}" /etc/ceph/ceph.conf"
	ssh ${ceph_node} "service ceph -a stop"
	sleep 5
	ssh ${ceph_node} "service ceph -a start"
	sleep 20

	./vm_reboot.sh "13 5 3 6" "1 2"
	sleep 30

	run_id="run"${id}
	qd=$i
	echo ${run_id}"_qd"${qd}
	./test.sh ${run_id} ${qd}
	mkdir ${result_path}${run_id}
	mv ${result_path}vmNum_* ${result_path}${run_id}
	id=`expr $id + 1`
done
