if [ $# != 2 ] ; then
    echo " "
    echo "Description:"
    echo "    This script attempts ."
    echo " "
    echo "usage:"
    echo "    $0 host time"
    echo " "
    exit
fi


i=$1
time=$2

# sync health check
   
iostat -dxm 1 5 > before_run_ceph-${i}_iostat.txt &
sar -A 1 5 > before_run_ceph-${i}_sar.txt &
cat /proc/interrupts > before_run_ceph-${i}_interrupts.txt &

./ceph_perf_counter_dump.sh ${time} 1 &
./check_cephHealth.sh ${time} 5 > ceph_health.txt &
top -n ${time} -b | grep  "osd" > ${i}_top.txt &

iostat -dxm 1  ${time} > ceph-${i}_iostat.txt &
sar -A 1 ${time} > ceph-${i}_sar.txt &
mpstat -P ALL 1 ${time} > ceph-${i}_mpstat.txt &

sleep ${time}
cat /proc/interrupts > ceph-${i}_interrupts.txt &
