#!/bin/sh

# help infomatin
if [ $# != 7 ] ; then
    echo " "
    echo "Description:"
    echo "   This script attempts to make run "aio-stress" on instance and collect data at the same time."
    echo " "
    echo "usage:"
    echo "    $0 start end operate record_size run_id qd ip_file"
    echo "    operation : write=0, read=1, random write=2, random read=3"
    echo " "
    exit 1
fi

start=$1
end=$2
operate=$3
record_size=$4
run_id=$5
qd=$6
ip_file=$7

run_time=600
#run_time=300
size="25g"

ceph_host="CephXCD"
#vm_host="node13"

number=`expr $end - $start`

# data dir
#dir="/mnt/ceph-"$ceph_host"/${run_id}/${operate}/${number}instance/${record_size}"
dir="/data/xcd/ceph-"$ceph_host"/${run_id}/${operate}/${number}instance/${record_size}"
if [ -d $dir ]
then
    echo "$dir already exist, Check it first !"
    exit 1
fi
mkdir -p $dir

# constanst


# clean ceph cache
echo "start to clean cache"
#for i in `seq 1 ${Ceph_num}` 
#Changed by xcd
#for i in `seq `
#do
   scp ./clean_cache_on_ceph.sh root@$ceph_host:~/ 
   ssh $ceph_host "./clean_cache_on_ceph.sh && sync"
#done

echo "start to run"
ssh $ceph_host "./check_readahead.sh"
#./check_disk_readahead.sh > $dir/check_disk_readahead.txt

# loop for test to run
echo "loop to start run !"
#for instance in `seq $start $end`
i=1
cat ${ip_file} | awk '{print $1}' | while read instance
do
	if [ "$i" -lt "$start" ];then
		continue
	elif [ "$i" -gt "$end" ];then
		break
	fi
	i=`expr $i + 1`
    ip=`cat ${ip_file} | grep ${instance} | awk '{print $2}'`
    vm_host=`cat ${ip_file} | grep ${instance} | awk '{print $3}'`
	flag=`cat vm_hosts | grep ${vm_host}`
	if [ -z $flag ];then
		vm_hosts=${vm_hosts}" ${vm_host}"
		echo ${vm_host} >> vm_hosts
	fi
	echo "${instance} $ip"
    scp ./volume-test_in_vm.sh root@${ip}:/home/
    scp ./all.fio root@${ip}:/home/
    ssh ${ip} "cd /home; ./volume-test_in_vm.sh ${operate} ${size} ${record_size} ${vm_host} ${instance} ${run_time} $qd&" &
done

cat vm_hosts | while read vm_host
do
	scp ./volume-test_in_pc.sh root@${vm_host}:/home/
	scp ./ceph_perf_counter_dump.sh root@${vm_host}:/home/
	ssh ${vm_host} "cd /home/; ./volume-test_in_pc.sh ${vm_host} ${run_time} &" &
done

scp ./volume-test_in_ceph.sh root@${ceph_host}:/home/
scp ./check_cephHealth.sh root@${ceph_host}:/home/
scp ./ceph_perf_counter_dump.sh root@${ceph_host}:/home/
ssh ${ceph_host} " cd /home/; ./volume-test_in_ceph.sh ${ceph_host} ${run_time}" &

sleep $run_time
sleep 10

echo "Sleep finished"

# killall aio-stress AND get data
#for instance in `seq $start $end`
for instance in `cat ${ip_file} | awk '{print $1}'`
do
	echo ${instance}
    ip=`cat ${ip_file} | grep ${instance} | awk '{print $2}'`
    ssh ${ip} "killall -9 sar;killall -9 iostat;killall -9 mpstat; killall -9 top" 
    scp ${ip}:/home/*.txt $dir
    ssh ${ip} "rm -f /home/*.txt" 
done

#cat vm_hosts | while read vm_host
for vm_host in `cat vm_hosts`
do
	echo ${vm_host}
    ssh ${vm_host} "killall -9 sar;killall -9 iostat;killall -9 mpstat; killall -9 top" 
    scp ${vm_host}:/home/*.txt $dir
    ssh ${vm_host} "rm -f /home/*.txt"
done
rm vm_hosts
ssh ${ip} "killall -9 sar;killall -9 iostat;killall -9 mpstat; killall -9 top" 
scp ${ceph_host}:/home/*.txt $dir
ssh ${ceph_host} "rm -f /home/*.txt"
