

cat /etc/ceph/ceph.conf |grep -A 5 "\[osd" | grep "host = ceph-" | awk -F= '{print $2}' > host.temp
cat /etc/ceph/ceph.conf |grep -A 5 "\[osd" | grep "devs = /dev/sd" | awk -F/ '{print $3}'| awk -F1 '{print $1}' > disk.temp
paste host.temp disk.temp > check.temp
total=`cat disk.temp | wc -l`

for i in `seq 1 ${total}`
do
    line=`sed -n ${i}p check.temp`
    host=`echo $line | awk '{print $1}'`
    disk=`echo $line | awk '{print $2}'`
    read_ahead_kb=`ssh $host "cat /sys/block/${disk}/queue/read_ahead_kb"`
    echo "$host $disk read_ahead_kb=$read_ahead_kb"
done

rm -f host.temp
rm -f disk.temp
rm -f check.temp
