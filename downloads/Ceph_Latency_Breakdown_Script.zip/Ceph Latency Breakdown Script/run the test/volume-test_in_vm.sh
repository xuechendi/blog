#!/bin/sh

if [ $# != 7 ] ; then
    echo " "
    echo "Description:"
    echo "    This script attempts to make run "aio-stress" and collect data at the same time."
    echo " "
    echo "usage:"
    echo "    $0 operate test_size record_size p_machine p_index time qd"
    echo "    operation : write=0, read=1, random write=2, random read=3"
    echo " "
    exit 1
fi

operate=$1
size=$2
record_size=$3
physical_compute_node=$4
p_index=$5
run_time=$6
qd=$7

case $operate in
"0")
   op="seq-write-${record_size}"
   ;;
"1")
   op="seq-read-${record_size}"
   ;;
"2")
   op="rand-write-${record_size}"
   ;;
"3")
   op="rand-read-${record_size}"
   ;;
*)
   echo "operation $operate is forbidden"
   exit 1
   ;;
esac

disk="/dev/vdb"

#./aio-stress -O -o ${operate} -i ${qd} -d ${qd} -r${record_size} -s ${size} ${disk} > /home/${physical_compute_node}_${p_index}_aio.txt &
#./aio-stress -O -o ${operate} -r${record_size} -s ${size} ${disk} > /home/${physical_compute_node}_${p_index}_aio.txt &


echo "QD=${qd} DISK=${disk} SIZE=${size} RECORD_SIZE=${record_size} RUNTIME=${run_time} fio --output /home/${physical_compute_node}_${p_index}_fio.txt --section ${op} all.fio &"

QD=${qd} DISK=${disk} SIZE=${size} RECORD_SIZE=${record_size} RUNTIME=${run_time} fio --output /home/${physical_compute_node}_${p_index}_fio.txt --section ${op} all.fio &

#sleep 30 
iostat -dxm 1  ${run_time} > /home/${physical_compute_node}_${p_index}_iostat.txt &
sar -A 1 ${run_time} > /home/${physical_compute_node}_${p_index}_sar.txt &
top -n ${run_time} -b | grep  " kvm$" > /home/${physical_compute_node}_${p_index}_top.txt &

# wait to collect data
sleep $run_time
#sleep 30
# end run
