if [ $# != 2 ] ; then
	echo " "
	echo "Description:"
	echo "	This script attempts to reboot vm on diffrent hosts "
	echo " "
	echo "usage:"
	echo '	$0 physical_hostname"13 3 5 6" vm_id"1 2"'
	echo " "
	exit
fi
hostlist=$1
vmlist=$2
ip_prefix="node"

for i in $hostlist; do
	for j in $vmlist; do
		echo 'ssh '${ip_prefix}${i}' "virsh destroy node'${i}'_'${j}'"'
		ssh ${ip_prefix}${i} "virsh destroy node${i}_${j}"
		echo 'ssh '${ip_prefix}${i}' "virsh create /var/lib/instances/node'${i}'_'${j}'/libvirt.xml"'
		ssh ${ip_prefix}${i} "virsh create /var/lib/instances/node${i}_${j}/libvirt.xml"
		echo 'ssh '${ip_prefix}${i}' "virsh attach-device node'${i}'_'${j}' /var/lib/instances/'${j}'"'
		ssh ${ip_prefix}${i} "virsh attach-device node${i}_${j} /var/lib/instances/${j}"
		ssh ${ip_prefix}${i} "virsh dumpxml node${i}_${j} | grep rbd "
	done
done
