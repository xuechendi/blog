#vm_all="651 652 653 654 655 656 657 658 659"
runid=$1
qd=$2
vm_all=`seq 1 4`
ceph_node="CephXCD"
VM_nodes="node13 node3 node5 node6"
log_node="192.168.10.31" 

echo "clean logs"
for VM_node in $VM_nodes
do
	for vm in $vm_all
	do
		vm_prefix=${VM_node}"_"
		ssh root@${VM_node} "echo > /var/log/libvirt/qemu/"${vm_prefix}${vm}".log"
	done
	for osd in `ssh root@${ceph_node} "ls /var/log/ceph | grep -v raw"`
	do
		ssh root@${ceph_node} "echo > /var/log/ceph/$osd"
	done
done
#exit
echo "start to test"
for vm_num in 8 7 6 5 4 3 2 1
do
#	ok=`ssh root@${ceph_node} "cd /home && ./check_cephHealth.sh 1 1 | grep HEALTH_OK"`
#	if [ -z "${ok}" ];then
#		ssh root@${ceph_node} "service ceph -a restart"
#	fi
#	sleep 30
	
	./mhost-volume-test-xcd.sh 1 $vm_num 3 4k "vmNum_"$vm_num ${qd} node13_net
#	./mhost-volume-test-xcd.sh 1 $vm_num 0 64k "vmNum_"$vm_num ${qd} node13_net
	sleep 30
#	./mhost-volume-test-xcd.sh 1 $vm_num 1 64k "vmNum_"$vm_num ${qd} node13_net
	sleep 30

#	for VM_node in $VM_nodes
#	do
#		ssh root@${VM_node} "mkdir -p /mnt/1TDisk/${runid} && sync" 
#		for vm in `seq 1 $vm_num`
#		do
#			vm_prefix=${VM_node}"_"
#			ssh root@${VM_node} "mkdir -p /mnt/1TDisk/${runid}/${vm_num} && sync" 
#			ssh root@${VM_node} "cp /var/log/libvirt/qemu/${vm_prefix}${vm}.log /mnt/1TDisk/${runid}/${vm_num}/${vm_num}_${vm}.log && sync" 
#			ssh root@${VM_node} "echo > /var/log/libvirt/qemu/${vm_prefix}${vm}.log"
#		done
#		ssh root@${log_node} "mkdir -p /mnt/result/${VM_node}/${runid}"
#		echo "Begin to process log from ${VM_node}"
#		ssh root@${log_node} "cd /root/log_parser/code_latency/ && ./test.sh '/mnt/${VM_node}log/${runid}/${vm_num}/' '/mnt/result/${VM_node}/${runid}/' &" &
#	done
#	ssh root@${ceph_node} "mkdir -p /mnt/10TDisk/${runid} && sync"
#	ssh root@${ceph_node} "mkdir /mnt/10TDisk/${runid}/${vm_num} && sync"
#	ssh root@${ceph_node} "cp /var/log/ceph/* /mnt/10TDisk/${runid}/${vm_num}/ && sync"
#	ssh root@${log_node} "mkdir -p /mnt/result/CephXCD/${runid}/${vm_num}"
#	echo "Begin to process log from ${ceph_node}"
#	ssh root@${log_node} "cd /root/log_parser/xiaoxi_log_pharser && ./run.sh '/mnt/cephlog/${runid}/${vm_num}' '/mnt/result/CephXCD/${runid}/${vm_num}' &" &
	
#	for osd in `ssh root@${ceph_node} "ls /var/log/ceph | grep -v raw"`
#	do
#		ssh root@${ceph_node} "echo > /var/log/ceph/$osd"
#	done
done
sleep 60
#ssh root@node3 "./code_latency.sh"
