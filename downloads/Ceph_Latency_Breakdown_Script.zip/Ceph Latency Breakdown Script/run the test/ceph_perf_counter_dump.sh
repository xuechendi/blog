if [ $# != 2 ];then
	echo "Usage: ./check_cephHeath.sh <runtime> <interval>"
	exit
fi
runtime=$1
interval=$2
runCount=`expr $runtime / $interval - 10`
#echo ${runCount}

for osd in `ls /var/run/ceph | grep asok`
do
	echo "[" > ${osd}.txt
done

for i in `seq 1 ${runCount}`
do
	for osd in `ls /var/run/ceph | grep asok`
	do
		ceph --admin-daemon /var/run/ceph/${osd} perf dump >> ${osd}.txt
		echo "," >> ${osd}.txt
	done
	sleep ${interval}
done

#for osd in `ls /var/run/ceph | grep asok`
#do
#	ceph --admin-daemon /var/run/ceph/${osd} perf dump >> ${osd}.txt
#done

#for osd in `ls /var/run/ceph | grep asok`
#do
#	echo "]" >> ${osd}.txt
#done	
