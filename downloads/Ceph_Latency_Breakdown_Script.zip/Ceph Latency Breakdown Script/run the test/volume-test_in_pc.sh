#!/bin/sh
if [ $# != 2 ] ; then
    echo " "
    echo "Description:"
    echo "    This script attempts ."
    echo " "
    echo "usage:"
    echo "    $0 host time"
    echo " "
    exit
fi

host=$1
time=$2

./ceph_perf_counter_dump.sh ${time} 1 &
iostat -dxm 1  ${time} > wc${host}_iostat.txt &
sar -A 1 ${time} > wc${host}_sar.txt &
top -n ${time} -b | grep  " kvm$" > /home/wc${host}_top.txt &

