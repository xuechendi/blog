if [ $# != 2 ];then
	echo "Usage: ./check_cephHeath.sh <runtime> <interval>"
	exit
fi
runtime=$1
interval=$2
runCount=$[ $runtime / $interval ]
echo ${runCount}

for i in `seq 1 ${runCount}`
do
	echo "============="`date +%Y%m%d_%H:%M:%S`"==============="
	ceph -s
	sleep ${interval} 
done  
